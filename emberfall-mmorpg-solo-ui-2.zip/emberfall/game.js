'use strict';
/* Emberfall — MMORPG เล่นคนเดียว (single-player first)
   โครงสร้าง: Net = จุดต่อเซิร์ฟเวอร์ในอนาคต, bots = ผู้เล่นจำลองให้บรรยากาศ MMO */
const $ = id => document.getElementById(id);
const cv = $('game'), ctx = cv.getContext('2d'), mctx = $('mini').getContext('2d');
const W = 2400, H = 1800, TOWN = { x: 1200, y: 900, r: 230 };
let vw = 0, vh = 0, cam = { x: 0, y: 0 };
const resize = () => { cv.width = vw = innerWidth; cv.height = vh = innerHeight; };
addEventListener('resize', resize); resize();
const rnd = (a, b) => a + Math.random() * (b - a);
const dist = (a, b) => Math.hypot(a.x - b.x, a.y - b.y);
const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
const OASIS = { x: 2080, y: 420, r: 130 }, TOWNS = [TOWN, OASIS], inSafe = o => TOWNS.some(t => dist(o, t) < t.r);
const ARENA = { x: 300, y: 1500, r: 250 }, DUN_IN = { x: 300, y: 1120 };

// ---- Net stub: ภายหลังเปลี่ยนเป็น WebSocket ได้ที่นี่ ----
const Net = { online: false, send(type, data) {} };

// ---- Player ----
const P = { x: TOWN.x, y: TOWN.y + 90, hp: 100, mp: 50, xp: 0, lvl: 1, gold: 30, pots: 3, weapon: 1,
  qi: 0, qp: 0, cls: null, sp: 0, sk: [1, 0, 0], inv: [], eq: {}, scd: [0, 0, 0], ring: 0, q2: '', q2p: 0, mat: { wood: 0, ore: 0 }, px: { w: 0, m: 0, c: 0 }, gath: null, node: null, cd: 0, fcd: 0, face: 0, sw: 0, go: null, tgt: null, npc: null };
const CLS = {
  warrior: { n: 'นักรบ', e: '🛡️', hp: 1.3, mp: .7, atk: 1, sk: [{ n: 'ฟัน', t: 'aoe', mp: 8, cd: 1, m: 1.8, r: 85 }, { n: 'คำราม', t: 'heal', mp: 15, cd: 4, m: 1 }, { n: 'ธรณีสั่น', t: 'aoe', mp: 25, cd: 6, m: 3.2, r: 160 }] },
  mage: { n: 'จอมเวท', e: '🧙', hp: .9, mp: 1.5, atk: 1.15, sk: [{ n: 'ลูกไฟ', t: 'proj', mp: 10, cd: .6, m: 2.2 }, { n: 'รักษา', t: 'heal', mp: 20, cd: 3, m: 1 }, { n: 'อุกกาบาต', t: 'aoe', mp: 30, cd: 6, m: 3.5, r: 150 }] },
  archer: { n: 'นักธนู', e: '🏹', hp: 1, mp: 1, atk: 1.05, sk: [{ n: 'ลูกศร', t: 'proj', mp: 6, cd: .4, m: 1.8 }, { n: 'สมุนไพร', t: 'heal', mp: 18, cd: 3, m: 1 }, { n: 'ห่าธนู', t: 'aoe', mp: 28, cd: 5, m: 3 , r: 150 }] } };
const cls = () => CLS[P.cls] || CLS.warrior;
const bonus = k => Object.values(P.eq).reduce((a, i) => a + (i && i[k] || 0), 0);
const maxHp = () => Math.round((80 + P.lvl * 20) * cls().hp) + bonus('h'), maxMp = () => Math.round((30 + P.lvl * 10) * cls().mp);
const atkVal = () => Math.round((6 + P.lvl * 2 + P.weapon * 4) * cls().atk) + bonus('a'), defVal = () => 1 + P.lvl + bonus('d');
const RAR = [{ n: 'ธรรมดา', c: '#ccc', m: 1 }, { n: 'หายาก', c: '#5dade2', m: 1.5 }, { n: 'ตำนาน', c: '#b36bff', m: 2.2 }, { n: 'มหากาพย์', c: '#ffa733', m: 3.2 }];
const SLOT = { weapon: ['ดาบ', '⚔️'], armor: ['เกราะ', '🥋'], ring: ['แหวน', '💍'] };
function mkItem(boost, sl) {
  const r = Math.random(), ri = r < .04 + boost * .1 ? 3 : r < .15 + boost * .2 ? 2 : r < .4 + boost * .3 ? 1 : 0;
  const slot = sl || ['weapon', 'armor', 'ring'][Math.floor(Math.random() * 3)], m = RAR[ri].m, L = Math.max(1, P.lvl), it = { slot, ri, n: SLOT[slot][0] + RAR[ri].n + ' Lv.' + L };
  if (slot === 'weapon') it.a = Math.round((3 + L * 1.5) * m); else if (slot === 'armor') { it.d = Math.round((1 + L * .8) * m); it.h = Math.round(L * 4 * m); } else { it.h = Math.round(L * 6 * m); it.a = Math.round(L * .6 * m); }
  return it;
}
const sell = it => Math.round((5 + P.lvl * 2) * RAR[it.ri].m * 2);
const itemTxt = i => SLOT[i.slot][1] + ' <span style="color:' + RAR[i.ri].c + '">' + i.n + '</span> ' + [i.a && '+' + i.a + ' โจมตี', i.d && '+' + i.d + ' ป้องกัน', i.h && '+' + i.h + ' HP'].filter(Boolean).join(' ');
const need = () => Math.floor(25 * Math.pow(P.lvl, 1.6));
const SAVE = ['x', 'y', 'hp', 'mp', 'xp', 'lvl', 'gold', 'pots', 'weapon', 'qi', 'qp', 'cls', 'sp', 'sk', 'inv', 'eq', 'mat', 'px', 'q2', 'q2p'];
function save() { try { localStorage.setItem('emberfall', JSON.stringify(Object.fromEntries(SAVE.map(k => [k, P[k]])))); } catch (e) {} }
function load() { try { const s = JSON.parse(localStorage.getItem('emberfall')); if (s) Object.assign(P, s); } catch (e) {} }
P.hp = maxHp(); P.mp = maxMp(); load();
if (dist(P, ARENA) < ARENA.r + 20) { P.x = DUN_IN.x; P.y = DUN_IN.y + 60; }

// ---- World ----
function rng(a) { return () => { a |= 0; a = a + 0x6D2B79F5 | 0; let t = Math.imul(a ^ a >>> 15, 1 | a); t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t; return ((t ^ t >>> 14) >>> 0) / 4294967296; }; }
const NPCS = [
  { id: 'shop', n: 'พ่อค้าบอร์ก', e: '🧔', x: TOWN.x - 100, y: TOWN.y - 70 },
  { id: 'quest', n: 'ผู้อาวุโสเอลดา', e: '🧓', x: TOWN.x + 100, y: TOWN.y - 70 },
  { id: 'smith', n: 'ช่างเหล็กกอร์ด', e: '👨', x: TOWN.x, y: TOWN.y + 130 },
  { id: 'q2', n: 'ผู้นำเผ่ากาซิม', e: '👳', x: OASIS.x - 50, y: OASIS.y - 30 },
  { id: 'shop', n: 'พ่อค้าทะเลทราย', e: '🧕', x: OASIS.x + 50, y: OASIS.y - 30 }];
const trees = [];
const bg = document.createElement('canvas'); bg.width = W; bg.height = H;
(function buildWorld() {
  const b = bg.getContext('2d'), R = rng(7);
  b.fillStyle = '#3f7d3a'; b.fillRect(0, 0, W, H);
  for (let i = 0; i < 1000; i++) { b.fillStyle = R() < .5 ? '#468a40' : '#377034'; b.beginPath(); b.arc(R() * W, R() * H, 8 + R() * 30, 0, 7); b.fill(); }
  const g = b.createRadialGradient(TOWN.x, TOWN.y, 500, TOWN.x, TOWN.y, 1400);
  g.addColorStop(0, 'rgba(0,0,0,0)'); g.addColorStop(1, 'rgba(10,0,30,.45)'); b.fillStyle = g; b.fillRect(0, 0, W, H);
  b.fillStyle = 'rgba(235,195,95,.5)'; b.fillRect(1750, 0, W - 1750, H); b.fillStyle = 'rgba(70,70,95,.55)'; b.fillRect(0, 0, 650, H);
  b.strokeStyle = '#a89a78'; b.lineWidth = 40; b.lineCap = 'round';
  [[1, 0], [-1, 0], [0, 1], [0, -1]].forEach(([dx, dy]) => { b.beginPath(); b.moveTo(TOWN.x, TOWN.y); b.lineTo(TOWN.x + dx * 560, TOWN.y + dy * 560); b.stroke(); });
  b.fillStyle = '#b8a98a'; b.beginPath(); b.arc(TOWN.x, TOWN.y, TOWN.r, 0, 7); b.fill();
  b.lineWidth = 6; b.strokeStyle = '#6d5a3c'; b.stroke();
  [[-150, -140], [150, -140], [-160, 120], [160, 120]].forEach(([dx, dy]) => {
    b.fillStyle = '#7a4e2d'; b.fillRect(TOWN.x + dx - 36, TOWN.y + dy - 26, 72, 52);
    b.fillStyle = '#a33'; b.beginPath(); b.moveTo(TOWN.x + dx - 44, TOWN.y + dy - 26); b.lineTo(TOWN.x + dx, TOWN.y + dy - 62); b.lineTo(TOWN.x + dx + 44, TOWN.y + dy - 26); b.fill(); });
  b.fillStyle = '#4aa3df'; b.beginPath(); b.arc(TOWN.x, TOWN.y + 10, 24, 0, 7); b.fill();
  b.fillStyle = '#d9c28a'; b.beginPath(); b.arc(OASIS.x, OASIS.y, OASIS.r, 0, 7); b.fill(); b.strokeStyle = '#8a6d3b'; b.lineWidth = 5; b.stroke(); b.fillStyle = '#3aa6c9'; b.beginPath(); b.arc(OASIS.x, OASIS.y + 25, 30, 0, 7); b.fill();
  b.fillStyle = '#2a1a1a'; b.beginPath(); b.arc(ARENA.x, ARENA.y, ARENA.r, 0, 7); b.fill(); b.lineWidth = 8; b.strokeStyle = '#c0392b'; b.stroke();
  for (let i = 0; i < 14; i++) { const an = i * .45, d0 = 40 + (i % 5) * 40; b.strokeStyle = 'rgba(255,110,30,.5)'; b.lineWidth = 3; b.beginPath(); b.moveTo(ARENA.x + Math.cos(an) * d0, ARENA.y + Math.sin(an) * d0); b.lineTo(ARENA.x + Math.cos(an + .3) * (d0 + 50), ARENA.y + Math.sin(an + .3) * (d0 + 50)); b.stroke(); }
  b.fillStyle = '#8e44ad'; b.beginPath(); b.arc(DUN_IN.x, DUN_IN.y, 26, 0, 7); b.fill(); b.fillStyle = '#5dade2'; b.beginPath(); b.arc(ARENA.x, ARENA.y + ARENA.r - 45, 20, 0, 7); b.fill();
  while (trees.length < 280) {
    const t = { x: 40 + R() * (W - 80), y: 40 + R() * (H - 80), s: 14 + R() * 10 };
    if (dist(t, TOWN) < TOWN.r + 50 || dist(t, OASIS) < OASIS.r + 40 || dist(t, ARENA) < ARENA.r + 40) continue;
    trees.push(t);
    b.fillStyle = '#5a3b1f'; b.fillRect(t.x - 3, t.y, 6, t.s * .8);
    b.fillStyle = '#1f5a2a'; b.beginPath(); b.arc(t.x, t.y - 4, t.s, 0, 7); b.fill();
    b.fillStyle = '#2b7a39'; b.beginPath(); b.arc(t.x - 3, t.y - 8, t.s * .6, 0, 7); b.fill();
  }
})();

// ---- Enemies ----
const T = {
  slime: { n: 'สไลม์', hp: 30, atk: 5, spd: 55, xp: 8, g: [2, 6], r: 14, aggro: 150, lv: 1 },
  wolf: { n: 'หมาป่า', hp: 70, atk: 10, spd: 115, xp: 22, g: [6, 14], r: 15, aggro: 230, lv: 3, e: '🐺' },
  goblin: { n: 'ก๊อบลิน', hp: 130, atk: 17, spd: 95, xp: 50, g: [12, 26], r: 15, aggro: 230, lv: 6, e: '👺' },
  ogre: { n: 'โอเกอร์', hp: 600, atk: 36, spd: 75, xp: 300, g: [100, 180], r: 30, aggro: 280, lv: 10, e: '👹' },
  drake: { n: 'มังกรเพลิง', hp: 1800, atk: 42, spd: 80, xp: 1500, g: [300, 500], r: 38, aggro: 600, lv: 15, e: '🐉' }};
const RING = { slime: [320, 650, 14], wolf: [650, 950, 12], goblin: [900, 1250, 10], ogre: [1000, 1250, 2] };
function spawn(type) {
  const [a, b] = RING[type]; let x, y, i = 0;
  do { const an = rnd(0, 6.283), d = rnd(a, b); x = TOWN.x + Math.cos(an) * d; y = TOWN.y + Math.sin(an) * d; }
  while ((x < 60 || x > W - 60 || y < 60 || y > H - 60 || inSafe({ x, y }) || dist({ x, y }, ARENA) < 600) && ++i < 300);
  x = clamp(x, 60, W - 60); y = clamp(y, 60, H - 60);
  const t = T[type];
  return { type, t, hx: x, hy: y, x, y, hp: t.hp, max: t.hp, cd: 0, dead: 0, rs: 0, agro: 0 };
}
const enemies = [];
for (const k in RING) for (let i = 0; i < RING[k][2]; i++) enemies.push(spawn(k));

// ---- Resource nodes ----
const NODE = { wood: { e: '🪵', t: 1.5, p: 'w' }, ore: { e: '🪨', t: 2, p: 'm' } };
const mkDrake = () => ({ type: 'drake', t: T.drake, hx: ARENA.x, hy: ARENA.y - 60, x: ARENA.x, y: ARENA.y - 60, hp: T.drake.hp, max: T.drake.hp, cd: 0, dead: 0, rs: 0, agro: 0, ph: 1, tc: 2, sc: 6 });
const boss = Object.assign(mkDrake(), { dead: 1, rs: 1e9 }); enemies.push(boss);
const nodes = [];
(function () { const R = rng(21); for (let i = 0; i < 30; i++) { const ore = i % 2, n = { type: ore ? 'ore' : 'wood', x: ore ? 60 + R() * 560 : 700 + R() * 1000, y: 60 + R() * (H - 120), rs: 0 }; if (dist(n, ARENA) > ARENA.r + 40 && dist(n, TOWN) > TOWN.r + 60) nodes.push(n); } })();

// ---- Quests / Bots / Chat ----
const QUESTS = [
  { t: 'slime', n: 5, txt: 'กำจัดสไลม์ 5 ตัว', gold: 40, xp: 40 },
  { t: 'wolf', n: 6, txt: 'ล่าหมาป่า 6 ตัว', gold: 100, xp: 120 },
  { t: 'goblin', n: 6, txt: 'ปราบก๊อบลิน 6 ตัว', gold: 200, xp: 300 },
  { t: 'ogre', n: 1, txt: 'สังหารโอเกอร์ 1 ตัว', gold: 500, xp: 800 }];
const SAY = ['ใครไปล่าหมาป่าฝั่งตะวันออกบ้าง?', 'ขายยาเลือดถูกๆ ที่ตลาด!', 'เพิ่งอัปเลเวลเลย เย้!', 'โอเกอร์โหดมาก ใครช่วยตีหน่อย',
  'LFG ปาร์ตี้ล่าก๊อบลิน', 'สไลม์มาอีกแล้ว...', 'ร้านพ่อค้าบอร์กอัปอาวุธคุ้มนะ', 'ระวังเลือดหมดนะทุกคน'];
const bots = ['KaiTH', 'Mintra', 'Zer0', 'NongBee', 'DarkFox', 'Pim', 'Arthit'].map(n => {
  const a = rnd(0, 6.283), d = rnd(60, 800);
  const x = TOWN.x + Math.cos(a) * d, y = TOWN.y + Math.sin(a) * d * .7;
  return { n, x, y, hx: x, hy: y, tx: x, ty: y, say: rnd(5, 20) };
});
const chatLog = [];
function chat(html) { chatLog.push(html); if (chatLog.length > 7) chatLog.shift(); $('chat').innerHTML = chatLog.join('<br>'); }
const sys = m => chat('<span class="sys">' + m + '</span>');
sys('ยินดีต้อนรับสู่ Emberfall! คุยกับผู้อาวุโสเอลดาเพื่อรับเควส · ทางตะวันออกมีโอเอซิสทะเลทราย');

// ---- Audio ----
let ac = null, music = true, ni = 0;
function sfx(f, d = .1, type = 'sine', v = .06) { if (!ac) return; try { const o = ac.createOscillator(), g = ac.createGain(); o.type = type; o.frequency.value = f; g.gain.setValueAtTime(v, ac.currentTime); g.gain.exponentialRampToValueAtTime(.0001, ac.currentTime + d); o.connect(g); g.connect(ac.destination); o.start(); o.stop(ac.currentTime + d); } catch (e) {} }
const NOTES = [220, 262, 330, 392, 330, 262, 294, 349, 440, 349, 294, 262];
setInterval(() => { if (music && ac) sfx(NOTES[ni++ % NOTES.length], .5, 'triangle', .025); }, 450);
const toggleMusic = () => { music = !music; sys('🎵 เพลง: ' + (music ? 'เปิด' : 'ปิด')); };
const initAudio = () => { if (!ac) try { ac = new AudioContext(); } catch (e) {} };
addEventListener('pointerdown', initAudio); addEventListener('keydown', initAudio);

// ---- Combat ----
const floats = [], shots = [], tele = [];
const addFloat = (x, y, txt, col = '#fff') => floats.push({ x, y, txt, col, t: 1 });
const nearestEnemy = r => { let best = null, bd = r; for (const e of enemies) { if (e.dead) continue; const d = dist(e, P) - e.t.r; if (d < bd) { bd = d; best = e; } } return best; };
function gain(xp) {
  P.xp += xp;
  while (P.xp >= need()) { P.xp -= need(); P.lvl++; P.sp++; P.hp = maxHp(); P.mp = maxMp(); sys('🎉 เลเวลอัป! ตอนนี้ Lv.' + P.lvl); addFloat(P.x, P.y - 40, 'LEVEL UP!', '#ffd54a'); sfx(988, .4, 'triangle', .08); }
}
function hit(e, d) {
  const crit = Math.random() < .15; d = Math.round(d * (crit ? 1.8 : 1));
  e.hp -= d; sfx(crit ? 320 : 200, .06, 'square', .04); e.agro = 1; addFloat(e.x, e.y - e.t.r - 10, (crit ? '💥' : '') + d, crit ? '#ffd54a' : '#fff');
  if (e.hp <= 0) kill(e);
}
function kill(e) {
  e.dead = 1; e.rs = e.type === 'drake' ? 1e9 : e.type === 'ogre' ? 60 : 15; if (e.type === 'drake') { tele.length = 0; sys('🏆 ปราบมังกรเพลิงได้แล้ว! ไปที่ประตูสีฟ้าแล้วกด E เพื่อออก'); } if (P.tgt === e) P.tgt = null;
  gain(e.t.xp); const g = Math.round(rnd(...e.t.g)); P.gold += g;
  addFloat(e.x, e.y - 20, '+' + g + '🪙', '#ffc857');
  if (Math.random() < .12) { P.pots++; sys('ได้รับ 🧪 ยาฟื้นเลือด'); }
  if (Math.random() < (e.type === 'ogre' || e.type === 'drake' ? 1 : .16)) { const it = mkItem(e.type === 'drake' ? 3 : e.type === 'ogre' ? 1 : 0); if (P.inv.length < 20) { P.inv.push(it); sys('ได้รับ ' + itemTxt(it)); sfx(880, .15); } else sys('กระเป๋าเต็ม!'); }
  const q = QUESTS[P.qi]; if (q && q.t === e.type && P.qp < q.n) { P.qp++; if (P.qp >= q.n) sys('เควสสำเร็จ! กลับไปหาผู้อาวุโสเอลดา'); }
  if (P.q2 === 'A' && e.type === 'goblin' && P.q2p < 8) { P.q2p++; if (P.q2p >= 8) sys('ปราบก๊อบลินครบ! กลับไปหาผู้นำกาซิม'); }
}
function attack(e) {
  if (P.cd > 0) return;
  e = e || P.tgt || nearestEnemy(90);
  if (!e || e.dead || dist(e, P) - e.t.r > 90) return;
  P.cd = .45; P.sw = .15; P.ring = 0;
  P.face = Math.atan2(e.y - P.y, e.x - P.x);
  hit(e, atkVal() * rnd(.85, 1.15));
}
function cast(i) {
  const k = cls().sk[i], r = P.sk[i]; if (!r) return addFloat(P.x, P.y - 40, 'ยังไม่ปลดล็อก (กด K)', '#fc6');
  if (P.scd[i] > 0) return; if (P.mp < k.mp) return addFloat(P.x, P.y - 40, 'MP ไม่พอ', '#6cf');
  P.mp -= k.mp; P.scd[i] = k.cd; const pw = atkVal() * k.m * (1 + .3 * (r - 1)), e = nearestEnemy(450);
  if (e && k.t !== 'heal') P.face = Math.atan2(e.y - P.y, e.x - P.x);
  if (k.t === 'proj') { shots.push({ x: P.x, y: P.y, vx: Math.cos(P.face) * 440, vy: Math.sin(P.face) * 440, life: 1, d: pw }); sfx(520, .12, 'sawtooth'); }
  else if (k.t === 'aoe') { P.sw = .3; P.ring = k.r; sfx(180, .25, 'square'); enemies.forEach(q => !q.dead && dist(q, P) < k.r + q.t.r && hit(q, pw * rnd(.9, 1.1))); }
  else { const h = Math.round((40 + P.lvl * 8) * (1 + .3 * (r - 1))); P.hp = Math.min(maxHp(), P.hp + h); addFloat(P.x, P.y - 40, '+' + h, '#6f6'); sfx(700, .25); }
}
function potion() {
  if (P.pots <= 0) return addFloat(P.x, P.y - 40, 'ไม่มียา', '#f88');
  P.pots--; P.hp = Math.min(maxHp(), P.hp + 60 + P.lvl * 5); addFloat(P.x, P.y - 40, '🧪', '#6f6');
}
function hurt(d) {
  d = Math.round(d); P.hp -= d; P.gath = null; addFloat(P.x, P.y - 30, '-' + d, '#f55');
  if (P.hp <= 0) {
    const lost = Math.floor(P.gold * .1); P.gold -= lost; P.hp = maxHp(); P.mp = maxMp();
    P.x = TOWN.x; P.y = TOWN.y + 90; leaveDun(true); P.go = P.tgt = P.npc = null; sys('💀 คุณพ่ายแพ้! เสีย ' + lost + '🪙 และฟื้นที่เมือง');
  }
}

// ---- NPC panel ----
let panelNpc = null;
function openPanel(n) { panelNpc = n; renderPanel(); }
function closePanel() { panelNpc = null; $('panel').hidden = true; }
const plv = k => Math.floor(Math.sqrt(P.px[k] / 4)) + 1;
function startGather(n) { if (n.rs > 0) return; P.gath = { n, t: NODE[n.type].t }; P.go = P.tgt = P.npc = P.node = null; }
const RECIPES = { pot: { n: '🧪 ยาฟื้นเลือด ×2', w: 2, o: 0 }, weapon: { n: '⚔️ ตีดาบ', w: 2, o: 4 }, armor: { n: '🥋 ตีเกราะ', w: 3, o: 5 }, ring: { n: '💍 ทำแหวน', w: 1, o: 3 } };
function q2Html() {
  const q = P.q2;
  if (q === '') return P.lvl < 5 ? '<p>ทะเลทรายอันตรายนัก... กลับมาเมื่อเจ้าถึง Lv.5</p>' : '<p>โอเอซิสของเรากำลังเดือดร้อน ก๊อบลินขโมยน้ำและเสบียง เจ้าจะช่วยอย่างไร?</p><button data-a="b:A">⚔️ ปราบก๊อบลิน 8 ตัว (รางวัล: ดาบหายาก + ทอง)</button><button data-a="b:B">🤝 ส่งไม้ 8 แร่ 6 สร้างกำแพง (รางวัล: แหวนหายาก + เลเวลช่าง)</button>';
  if (q === 'A') return '<p>ก๊อบลินที่ปราบแล้ว: ' + P.q2p + '/8</p>' + (P.q2p >= 8 ? '<button data-a="b:done">รับรางวัล</button>' : '');
  if (q === 'B') return '<p>ต้องการไม้ 8 แร่ 6 (เจ้ามี ' + P.mat.wood + ' / ' + P.mat.ore + ')</p>' + (P.mat.wood >= 8 && P.mat.ore >= 6 ? '<button data-a="b:done">ส่งมอบ</button>' : '');
  return q === 'doneA' ? '<p>วีรบุรุษผู้พิทักษ์! ชาวโอเอซิสร้องเพลงสรรเสริญเจ้า 🏆<br><i>(ตอนจบ: เส้นทางนักรบ)</i></p>' : '<p>กำแพงใหม่ทำให้โอเอซิสเจริญรุ่งเรือง 🏆<br><i>(ตอนจบ: เส้นทางพ่อค้า)</i></p>';
}
function smithHtml() {
  return '<div class="gold">🪵 ' + P.mat.wood + ' · 🪨 ' + P.mat.ore + ' · ช่าง Lv.' + plv('c') + ' (ยิ่งเลเวลสูง ของยิ่งหายาก)</div>' + Object.keys(RECIPES).map(k => { const r = RECIPES[k]; return '<button data-a="f:' + k + '">' + r.n + ' (🪵' + r.w + ' 🪨' + r.o + ')</button>'; }).join('');
}
function invHtml() {
  const eqs = ['weapon', 'armor', 'ring'].map(k => P.eq[k] ? '<button data-a="u:' + k + '">' + itemTxt(P.eq[k]) + ' (ถอด)</button>' : '<div>' + SLOT[k][1] + ' ' + SLOT[k][0] + ': ว่าง</div>').join('');
  const bag = P.inv.map((it, i) => '<button style="width:72%;display:inline-block" data-a="e:' + i + '">' + itemTxt(it) + '</button><button style="width:24%;display:inline-block;margin-left:2%" data-a="s:' + i + '">ขาย ' + sell(it) + '</button>').join('');
  return '<div class="gold">🪵 ' + P.mat.wood + ' · 🪨 ' + P.mat.ore + ' · 🪓Lv.' + plv('w') + ' ⛏️Lv.' + plv('m') + ' 🔨Lv.' + plv('c') + '</div><b>สวมใส่อยู่</b>' + eqs + '<br><b>กระเป๋า (' + P.inv.length + '/20)</b>' + (bag || '<div>ว่างเปล่า</div>');
}
function skHtml() {
  return '<div class="gold">แต้มสกิล: ' + P.sp + ' (ได้ 1 แต้มต่อเลเวล)</div>' + cls().sk.map((k, i) => '<button data-a="k:' + i + '">' + (i + 1) + '. ' + k.n + ' ระดับ ' + P.sk[i] + '/4 · ' + k.mp + ' MP' + (P.sk[i] ? '' : ' (กดเพื่อปลดล็อก)') + '</button>').join('');
}
function renderPanel() {
  const p = $('panel'); if (!panelNpc) { p.hidden = true; return; } p.hidden = false;
  let h = '<b>' + panelNpc.e + ' ' + panelNpc.n + '</b><div class="gold">🪙 ' + P.gold + ' · 🧪 ' + P.pots + ' · อาวุธ +' + P.weapon + '</div>';
  if (panelNpc.id === 'cls') h += Object.keys(CLS).map(k => '<button data-a="c:' + k + '">' + CLS[k].e + ' ' + CLS[k].n + '</button>').join('');
  else if (panelNpc.id === 'inv') h += invHtml();
  else if (panelNpc.id === 'sk') h += skHtml();
  else if (panelNpc.id === 'q2') h += q2Html();
  else if (panelNpc.id === 'smith') h += smithHtml();
  else if (panelNpc.id === 'shop') h += '<button data-a="buy">ซื้อยาฟื้นเลือด (25🪙)</button><button data-a="up">อัปเกรดอาวุธเป็น +' + (P.weapon + 1) + ' (' + 60 * P.weapon + '🪙)</button>';
  else { const q = QUESTS[P.qi];
    if (!q) h += '<p>เจ้าทำภารกิจครบทุกอย่างแล้ว วีรบุรุษ!</p>';
    else { h += '<p>' + q.txt + ' (' + Math.min(P.qp, q.n) + '/' + q.n + ')<br>รางวัล: 🪙' + q.gold + ' + XP ' + q.xp + '</p>'; if (P.qp >= q.n) h += '<button data-a="claim">ส่งเควส</button>'; } }
  p.innerHTML = h + (panelNpc.id === 'cls' ? '' : '<button data-a="close">ปิด</button>');
}
$('panel').onclick = e => {
  const el = e.target.closest('[data-a]'), a = el && el.dataset.a; if (!a) return;
  if (a === 'close') return closePanel();
  if (a[1] === ':') {
    const [k, v] = a.split(':');
    if (k === 'c') { P.cls = v; P.hp = maxHp(); P.mp = maxMp(); closePanel(); sys('คุณเลือกเป็น' + cls().n + '! กด K เพื่อเรียนสกิล'); sfx(660, .2); return; }
    if (k === 'e') { const it = P.inv[+v]; if (it) { const old = P.eq[it.slot]; P.eq[it.slot] = it; P.inv.splice(+v, 1); if (old) P.inv.push(old); } }
    if (k === 'u' && P.inv.length < 20) { P.inv.push(P.eq[v]); delete P.eq[v]; }
    if (k === 's') { const it = P.inv[+v]; if (it) { P.gold += sell(it); P.inv.splice(+v, 1); } }
    if (k === 'k' && P.sp > 0 && P.sk[+v] < 4) { P.sp--; P.sk[+v]++; }
    if (k === 'b') {
      if ((v === 'A' || v === 'B') && !P.q2 && P.lvl >= 5) { P.q2 = v; P.q2p = 0; sys('📜 รับเควสโอเอซิส'); }
      else if (P.q2 === 'A' && P.q2p >= 8 && P.inv.length < 20) { P.q2 = 'doneA'; P.gold += 400; gain(500); P.inv.push(mkItem(1.5, 'weapon')); sys('🏆 จบเควสโอเอซิส (เส้นทางนักรบ)'); }
      else if (P.q2 === 'B' && P.mat.wood >= 8 && P.mat.ore >= 6 && P.inv.length < 20) { P.q2 = 'doneB'; P.mat.wood -= 8; P.mat.ore -= 6; P.gold += 250; gain(300); P.px.c += 12; P.inv.push(mkItem(1.5, 'ring')); sys('🏆 จบเควสโอเอซิส (เส้นทางพ่อค้า)'); }
    }
    if (k === 'f') { const r = RECIPES[v]; if (P.mat.wood >= r.w && P.mat.ore >= r.o && (v === 'pot' || P.inv.length < 20)) { P.mat.wood -= r.w; P.mat.ore -= r.o; P.px.c += 3; if (v === 'pot') P.pots += 2; else { const it = mkItem(.3 + .12 * plv('c'), v); P.inv.push(it); sys('🔨 ตีได้ ' + itemTxt(it)); } sfx(440, .2, 'square'); } else addFloat(P.x, P.y - 40, 'วัตถุดิบหรือที่ว่างไม่พอ', '#f88'); }
    P.hp = Math.min(P.hp, maxHp()); renderPanel(); return;
  }
  if (a === 'buy' && P.gold >= 25) { P.gold -= 25; P.pots++; }
  if (a === 'up' && P.gold >= 60 * P.weapon) { P.gold -= 60 * P.weapon; P.weapon++; sys('⚔️ อัปเกรดอาวุธเป็น +' + P.weapon); }
  if (a === 'claim') { const q = QUESTS[P.qi]; if (q && P.qp >= q.n) { P.gold += q.gold; gain(q.xp); P.qi++; P.qp = 0; sys('ได้รับรางวัลเควส 🪙' + q.gold); } }
  renderPanel();
};
function leaveDun(dead) { if (!P.dun) return; P.dun = 0; boss.dead = 1; boss.rs = 1e9; tele.length = 0; if (!dead) { P.x = DUN_IN.x; P.y = DUN_IN.y + 60; } }
function interact() { let b = null, bd = 100; for (const n of NPCS) { const d = dist(n, P); if (d < bd) { bd = d; b = n; } } if (b) return openPanel(b);
  if (!P.dun && dist(P, DUN_IN) < 70) { P.dun = 1; Object.assign(boss, mkDrake()); P.x = ARENA.x; P.y = ARENA.y + 150; P.go = P.tgt = P.npc = P.node = null; sys(P.lvl < 8 ? '⚠️ มังกรเพลิงอันตรายมาก แนะนำ Lv.8 ขึ้นไป' : '🐉 คุณก้าวเข้าสู่ถ้ำมังกรเพลิง!'); return; }
  if (P.dun && dist(P, { x: ARENA.x, y: ARENA.y + ARENA.r - 45 }) < 70) return leaveDun();
  const g = nodes.find(n => n.rs <= 0 && dist(n, P) < 70); if (g) startGather(g); }

// ---- Input ----
const keys = {};
addEventListener('keydown', e => {
  const k = e.key.toLowerCase();
  if ([' ', 'arrowup', 'arrowdown', 'arrowleft', 'arrowright'].includes(k)) e.preventDefault();
  if (keys[k]) return;
  keys[k] = 1;
  if (k === '1') cast(0);
  if (k === '2') cast(1);
  if (k === '3') cast(2);
  if (k === 'i') openInv();
  if (k === 'k') openSk();
  if (k === 'm') toggleMusic();
  if (k === 'q') potion();
  if (k === 'e') interact();
  if (k === 'escape') closePanel();
  if (k === ' ' || k === 'f') attack();
});
addEventListener('keyup', e => keys[e.key.toLowerCase()] = 0);
cv.addEventListener('pointerdown', e => {
  // เดินด้วยปุ่ม/จอยเท่านั้น — แตะพื้นไม่เดิน
  const m = { x: e.clientX + cam.x, y: e.clientY + cam.y };
  const en = enemies.find(q => !q.dead && dist(q, m) < q.t.r + 18);
  const np = NPCS.find(n => dist(n, m) < 36);
  const nd = nodes.find(n => n.rs <= 0 && dist(n, m) < 36);
  if (en) {
    P.gath = null; P.tgt = en; P.npc = P.node = P.go = null;
    return;
  }
  if (np) {
    if (dist(np, P) < 70) openPanel(np);
    else sys('เดินเข้าใกล้อีกนิด แล้วกด E หรือแตะอีกครั้ง');
    return;
  }
  if (nd) {
    if (dist(nd, P) < 70) startGather(nd);
    else sys('เดินเข้าใกล้ทรัพยากร แล้วกด E หรือแตะอีกครั้ง');
    return;
  }
  // แตะพื้นว่าง = ไม่ทำอะไร (ไม่เดิน)
});
const openInv = () => openPanel({ id: 'inv', n: 'กระเป๋า', e: '🎒' }), openSk = () => openPanel({ id: 'sk', n: 'ต้นไม้สกิล', e: '🌟' });
const bindBtn = (id, fn) => { const el = $(id); el.addEventListener('pointerdown', e => { e.preventDefault(); e.stopPropagation(); fn(); }); };
bindBtn('b1', () => cast(0)); bindBtn('b2', () => cast(1)); bindBtn('b6', () => cast(2));
bindBtn('b7', openInv); bindBtn('b8', openSk); bindBtn('b3', potion); bindBtn('b4', interact); bindBtn('b5', () => attack());
$('reset').onclick = () => { try { localStorage.removeItem('emberfall'); } catch (e) {} P.hp = 0; location.reload(); };
addEventListener('beforeunload', save);
$('fs').onclick = async () => { try { if (!document.fullscreenElement) { await document.documentElement.requestFullscreen(); try { await screen.orientation.lock('landscape'); } catch (e) {} } else await document.exitFullscreen(); } catch (e) { sys('อุปกรณ์นี้ไม่รองรับโหมดเต็มจอ ลองหมุนจอเองได้เลย'); } };
$('rotx').onclick = () => $('rot').classList.add('off');
const joy = { x: 0, y: 0 };
(function () {
  const base = $('joy'), knob = $('knob'); let id = null;
  const set = e => { const r = base.getBoundingClientRect(), R = r.width / 2; let dx = e.clientX - (r.left + R), dy = e.clientY - (r.top + R); const d = Math.hypot(dx, dy), m = Math.min(d, R * .7);
    if (d > 0) { dx = dx / d * m; dy = dy / d * m; } knob.style.transform = 'translate(' + dx + 'px,' + dy + 'px)';
    const on = d > R * .15; joy.x = on ? dx / m * (m / (R * .7)) : 0; joy.y = on ? dy / m * (m / (R * .7)) : 0; };
  base.addEventListener('pointerdown', e => { id = e.pointerId; base.setPointerCapture(id); set(e); });
  base.addEventListener('pointermove', e => { if (e.pointerId === id) set(e); });
  const end = e => { if (e.pointerId === id) { id = null; joy.x = joy.y = 0; knob.style.transform = ''; } };
  base.addEventListener('pointerup', end); base.addEventListener('pointercancel', end);
})();
document.body.classList.toggle('joy-on', matchMedia('(pointer:coarse)').matches || 'ontouchstart' in window);
$('jt').onclick = () => document.body.classList.toggle('joy-on');

 setInterval(save, 5000);

// ---- Update ----
function update(dt) {
  P.cd -= dt; P.scd = P.scd.map(c => c - dt); P.fcd -= dt; P.sw -= dt;
  let mx = (keys.d || keys.arrowright ? 1 : 0) - (keys.a || keys.arrowleft ? 1 : 0), my = (keys.s || keys.arrowdown ? 1 : 0) - (keys.w || keys.arrowup ? 1 : 0); if (!mx && !my && (joy.x || joy.y)) { mx = joy.x; my = joy.y; }
  let dx = 0, dy = 0;
  // เดินด้วยปุ่ม/จอย — ไม่เคลียร์เป้า เพื่อให้โจมตี/สกิลได้ขณะเดิน
  if (mx || my) { P.go = null; dx = mx; dy = my; }
  else if (P.tgt) {
    if (P.tgt.dead) P.tgt = null;
    else if (dist(P, P.tgt) > P.tgt.t.r + 40) { dx = P.tgt.x - P.x; dy = P.tgt.y - P.y; }
  }
  else if (P.go) {
    const ddx = P.go.x - P.x, ddy = P.go.y - P.y;
    if (Math.hypot(ddx, ddy) < (P.npc || P.node ? 55 : 6)) {
      P.go = null;
      if (P.npc) { openPanel(P.npc); P.npc = null; }
      if (P.node) { startGather(P.node); P.node = null; }
    } else { dx = ddx; dy = ddy; }
  }
  for (const n of nodes) n.rs -= dt;
  if (P.gath) {
    if (mx || my || P.gath.n.rs > 0) P.gath = null;
    else if ((P.gath.t -= dt) <= 0) {
      const n = P.gath.n, d = NODE[n.type], k = d.p, y = 1 + (Math.random() < .12 * (plv(k) - 1) ? 1 : 0);
      P.mat[n.type] += y; P.px[k]++; n.rs = 20; P.gath = null;
      addFloat(P.x, P.y - 40, '+' + y + d.e, '#fff'); sfx(330, .1, 'triangle');
    }
  }
  // โจมตีได้ขณะเดิน: กด Space / มีเป้าในระยะ
  if (keys[' '] || keys['f']) attack();
  else if (P.tgt && !P.tgt.dead && dist(P, P.tgt) - P.tgt.t.r <= 90) attack(P.tgt);
  const l = Math.hypot(dx, dy);
  if (l > 0) {
    if (!(P.tgt && !P.tgt.dead && dist(P, P.tgt) - P.tgt.t.r <= 90))
      P.face = Math.atan2(dy, dx);
    P.x = clamp(P.x + dx / l * 170 * dt, 10, W - 10);
    P.y = clamp(P.y + dy / l * 170 * dt, 10, H - 10);
  }
  for (const t of trees) { const d = Math.hypot(P.x - t.x, P.y - t.y); if (d < 16) { P.x = t.x + (P.x - t.x) / (d || 1) * 16; P.y = t.y + (P.y - t.y) / (d || 1) * 16; } }
  if (P.dun) { const ad = dist(P, ARENA); if (ad > ARENA.r - 14) { P.x = ARENA.x + (P.x - ARENA.x) / ad * (ARENA.r - 14); P.y = ARENA.y + (P.y - ARENA.y) / ad * (ARENA.r - 14); } }
  const inTown = inSafe(P);
  P.hp = Math.min(maxHp(), P.hp + maxHp() * (inTown ? .05 : .008) * dt); P.mp = Math.min(maxMp(), P.mp + (inTown ? 6 : 2) * dt);
  if (panelNpc && dist(panelNpc, P) > 140) closePanel();

  for (const e of enemies) {
    if (e.dead) { if ((e.rs -= dt) <= 0) Object.assign(e, spawn(e.type)); continue; }
    e.cd -= dt; const d = dist(e, P), home = { x: e.hx, y: e.hy }; let tx = null, ty = null, chase = false;
    if (!inTown && (d < e.t.aggro || e.agro) && dist(e, home) < 500) { tx = P.x; ty = P.y; chase = true; }
    else { e.agro = 0; if (dist(e, home) > 8) { tx = e.hx; ty = e.hy; } }
    if (tx !== null) {
      const ex = tx - e.x, ey = ty - e.y, len = Math.hypot(ex, ey) || 1;
      if (!chase || len > e.t.r + 14) { const nx = e.x + ex / len * e.t.spd * dt, ny = e.y + ey / len * e.t.spd * dt; if (!inSafe({ x: nx, y: ny })) { e.x = nx; e.y = ny; } }
    }
    if (e.type === 'ogre' && chase && (e.tc = (e.tc || 3) - dt) <= 0) { e.tc = 4; tele.push({ x: P.x, y: P.y, r: 80, t: 1.3 }); }
    if (e.type === 'drake') {
      const ph = e.hp < e.max / 3 ? 3 : e.hp < e.max * 2 / 3 ? 2 : 1; if (ph !== e.ph) { e.ph = ph; sys('🐉 มังกรเพลิงเข้าสู่ระยะที่ ' + ph + '!'); sfx(70, .6, 'sawtooth', .1); }
      if ((e.tc -= dt) <= 0) { e.tc = [0, 3, 2.4, 1.8][ph]; for (let i = 0; i < ph; i++) tele.push({ x: P.x + (i ? rnd(-140, 140) : 0), y: P.y + (i ? rnd(-140, 140) : 0), r: 70, t: 1.3, d: 60 + P.lvl * 3 }); }
      if (ph >= 2 && (e.sc -= dt) <= 0) { e.sc = 8; tele.push({ x: e.x, y: e.y, r: 190, t: 1.6, d: 80 + P.lvl * 3 }); sys('🔥 มังกรกำลังรวบรวมพลัง ออกห่างตัวมัน!'); }
    }
    if (d < e.t.r + 24 && e.cd <= 0 && !inTown) { e.cd = 1.1; hurt(Math.max(1, e.t.atk * rnd(.8, 1.2) - defVal())); }
  }
  for (let i = shots.length - 1; i >= 0; i--) {
    const s = shots[i]; s.x += s.vx * dt; s.y += s.vy * dt; s.life -= dt;
    const e = enemies.find(q => !q.dead && dist(q, s) < q.t.r + 8);
    if (e) { hit(e, s.d * rnd(.9, 1.1)); s.life = 0; } if (s.life <= 0) shots.splice(i, 1);
  }
  for (let i = tele.length - 1; i >= 0; i--) { const z = tele[i]; if ((z.t -= dt) <= 0) { if (dist(z, P) < z.r + 10) hurt(z.d || 100); sfx(90, .3, 'square'); tele.splice(i, 1); } }
  for (const b of bots) {
    if (dist(b, { x: b.tx, y: b.ty }) < 6) { b.tx = clamp(b.hx + rnd(-200, 200), 40, W - 40); b.ty = clamp(b.hy + rnd(-200, 200), 40, H - 40); if (Math.random() < .4) { b.tx = b.x; b.ty = b.y; } }
    const bx = b.tx - b.x, by = b.ty - b.y, bl = Math.hypot(bx, by) || 1; if (bl > 6) { b.x += bx / bl * 70 * dt; b.y += by / bl * 70 * dt; }
    if ((b.say -= dt) <= 0) { b.say = rnd(10, 25); chat('<b>' + b.n + ':</b> ' + SAY[Math.floor(Math.random() * SAY.length)]); }
  }
  for (let i = floats.length - 1; i >= 0; i--) { const f = floats[i]; f.y -= 30 * dt; if ((f.t -= dt) <= 0) floats.splice(i, 1); }
}

// ---- Draw ----
const label = (t, x, y, c = '#fff') => { ctx.font = '11px sans-serif'; ctx.textAlign = 'center'; ctx.lineWidth = 3; ctx.strokeStyle = '#000a'; ctx.strokeText(t, x, y); ctx.fillStyle = c; ctx.fillText(t, x, y); };
const emoji = (e, x, y, s = 28) => { ctx.font = s + 'px serif'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillText(e, x, y); ctx.textBaseline = 'alphabetic'; };
const shadow = (x, y, r) => { ctx.fillStyle = '#0004'; ctx.beginPath(); ctx.ellipse(x, y + r * .7, r, r * .4, 0, 0, 7); ctx.fill(); };
function draw() {
  cam.x = clamp(P.x - vw / 2, 0, Math.max(0, W - vw)); cam.y = clamp(P.y - vh / 2, 0, Math.max(0, H - vh));
  ctx.fillStyle = '#1b2a1b'; ctx.fillRect(0, 0, vw, vh); ctx.drawImage(bg, -cam.x, -cam.y);
  ctx.save(); ctx.translate(-cam.x, -cam.y);
  for (const n of nodes) if (n.rs <= 0) { shadow(n.x, n.y, 12); emoji(NODE[n.type].e, n.x, n.y, 26); }
  for (const n of NPCS) { shadow(n.x, n.y, 14); emoji(n.e, n.x, n.y); label(n.n, n.x, n.y - 24, '#ffe28a'); }
  for (const b of bots) { shadow(b.x, b.y, 12); emoji('🧑', b.x, b.y); label(b.n, b.x, b.y - 22, '#8ec5ff'); }
  for (const e of enemies) {
    if (e.dead) continue; const r = e.t.r; shadow(e.x, e.y, r);
    if (e.type === 'slime') {
      ctx.fillStyle = '#5fd35f'; ctx.beginPath(); ctx.ellipse(e.x, e.y, r, r * .8, 0, Math.PI, 0); ctx.lineTo(e.x + r, e.y + r * .5); ctx.lineTo(e.x - r, e.y + r * .5); ctx.fill();
      ctx.fillStyle = '#123'; ctx.fillRect(e.x - 6, e.y - 4, 3, 5); ctx.fillRect(e.x + 3, e.y - 4, 3, 5);
    } else emoji(e.t.e, e.x, e.y, r * 2);
    if (e.hp < e.max || P.tgt === e) {
      ctx.fillStyle = '#000a'; ctx.fillRect(e.x - 18, e.y - r - 12, 36, 5); ctx.fillStyle = '#e74c3c'; ctx.fillRect(e.x - 18, e.y - r - 12, 36 * e.hp / e.max, 5);
      label(e.t.n + ' Lv.' + e.t.lv, e.x, e.y - r - 16, '#fcc');
    }
  }
  shadow(P.x, P.y, 14); emoji(cls().e, P.x, P.y); label('คุณ', P.x, P.y - 24, '#ffd54a');
  label('🌀 ถ้ำมังกร (E)', DUN_IN.x, DUN_IN.y - 34, '#d7a8ff'); label('🌀 ทางออก (E)', ARENA.x, ARENA.y + ARENA.r - 79, '#9cf');
  if (P.gath) { ctx.fillStyle = '#000a'; ctx.fillRect(P.x - 20, P.y - 38, 40, 5); ctx.fillStyle = '#6cf'; ctx.fillRect(P.x - 20, P.y - 38, 40 * (1 - P.gath.t / NODE[P.gath.n.type].t), 5); }
  if (P.sw > 0) { ctx.strokeStyle = 'rgba(255,255,255,.85)'; ctx.lineWidth = 4; ctx.beginPath(); ctx.arc(P.x, P.y, P.ring || 44, P.ring ? 0 : P.face - .9, P.ring ? 7 : P.face + .9); ctx.stroke(); }
  for (const z of tele) { ctx.fillStyle = 'rgba(255,40,40,' + (.15 + .3 * (1 - z.t / 1.3)) + ')'; ctx.beginPath(); ctx.arc(z.x, z.y, z.r, 0, 7); ctx.fill(); }
  for (const s of shots) { ctx.fillStyle = '#ff7a1a'; ctx.beginPath(); ctx.arc(s.x, s.y, 8, 0, 7); ctx.fill(); ctx.fillStyle = '#ffe28a'; ctx.beginPath(); ctx.arc(s.x, s.y, 4, 0, 7); ctx.fill(); }
  for (const f of floats) { ctx.globalAlpha = clamp(f.t * 2, 0, 1); ctx.font = 'bold 14px sans-serif'; ctx.textAlign = 'center'; ctx.lineWidth = 3; ctx.strokeStyle = '#000'; ctx.strokeText(f.txt, f.x, f.y); ctx.fillStyle = f.col; ctx.fillText(f.txt, f.x, f.y); }
  ctx.globalAlpha = 1; ctx.restore();
  const dk = .5 - .5 * Math.cos(performance.now() / 40000); ctx.fillStyle = 'rgba(5,10,45,' + (dk * .5).toFixed(2) + ')'; ctx.fillRect(0, 0, vw, vh);
  if (P.dun && !boss.dead) { const bw = Math.min(360, vw - 40), bx = (vw - bw) / 2; ctx.fillStyle = '#000a'; ctx.fillRect(bx, 70, bw, 14); ctx.fillStyle = ['', '#e67e22', '#e74c3c', '#ff2a2a'][boss.ph]; ctx.fillRect(bx, 70, bw * Math.max(0, boss.hp) / boss.max, 14); ctx.font = '12px sans-serif'; ctx.textAlign = 'center'; ctx.fillStyle = '#fff'; ctx.fillText('🐉 มังกรเพลิง — ระยะ ' + boss.ph + '/3', vw / 2, 66); }
  // minimap
  const k = 120 / W; mctx.drawImage(bg, 0, 0, 120, 90);
  const dot = (o, c, s = 2) => { mctx.fillStyle = c; mctx.fillRect(o.x * k - s / 2, o.y * k - s / 2, s, s); };
  enemies.forEach(e => !e.dead && dot(e, '#f44')); bots.forEach(b => dot(b, '#8ec5ff')); NPCS.forEach(n => dot(n, '#ffe28a', 3)); dot(P, '#fff', 4);
}

// ---- HUD ----
function hud() {
  $('lvl').textContent = 'Lv.' + P.lvl + ' ' + cls().n + ' · ' + (inSafe(P) ? 'เขตปลอดภัย' : P.dun ? 'ถ้ำมังกรเพลิง' : P.x < 650 ? 'ถ้ำ' : P.x > 1750 ? 'ทะเลทราย' : 'ป่า') + (P.sp ? ' · 🌟' + P.sp : '');
  const bar = (id, v, m) => { $(id + 'Bar').style.width = clamp(v / m * 100, 0, 100) + '%'; $(id + 'Txt').textContent = Math.ceil(v) + ' / ' + m; };
  bar('hp', P.hp, maxHp()); bar('mp', P.mp, maxMp()); bar('xp', P.xp, need());
  $('gold').textContent = '🪙 ' + P.gold + '   🧪 ' + P.pots + '   ⚔️ +' + P.weapon + '   🪵' + P.mat.wood + ' 🪨' + P.mat.ore;
  ['b1', 'b2', 'b6'].forEach((id, i) => { const b = $(id), c = P.scd[i], h = (i + 1) + '<small>' + (c > 0 ? c.toFixed(1) : cls().sk[i].n) + '</small>'; if (b.dataset.h !== h) { b.dataset.h = h; b.innerHTML = h; } b.style.opacity = P.sk[i] ? 1 : .35; });
  const q = QUESTS[P.qi];
  $('quest').textContent = !q ? 'เควสครบทุกอย่างแล้ว 🏆' : (P.qp >= q.n ? '✅ ' + q.txt + ' — กลับไปหาเอลดา' : '📜 ' + q.txt + ' (' + P.qp + '/' + q.n + ')');
  if (P.q2 === 'A') $('quest').textContent += ' | 🏜️ ปกป้องโอเอซิส ' + P.q2p + '/8'; else if (P.q2 === 'B') $('quest').textContent += ' | 🏜️ ส่งไม้ 8 แร่ 6';
}

if (!P.cls) openPanel({ id: 'cls', n: 'เลือกอาชีพของคุณ', e: '⚔️' });
let last = performance.now();
(function loop(t) { const dt = Math.min(.05, (t - last) / 1000); last = t; update(dt); draw(); hud(); requestAnimationFrame(loop); })(last);
